package com.example.yoges.moviesloverz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class AdminOption extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_option);
        getSupportActionBar().setTitle("Movie Database");
    }

    public void Option(View view) {
        switch (view.getId()) {
         case R.id.AddMovie :  startActivity(new Intent(AdminOption.this, AddMovie.class));
         break;
         case R.id.DeleteMovies:; startActivity(new Intent(getApplicationContext(),DeleteMovies.class));
         break;
         default:;
        }
    }
}
