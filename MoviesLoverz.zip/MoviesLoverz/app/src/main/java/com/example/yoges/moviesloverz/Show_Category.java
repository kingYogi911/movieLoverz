package com.example.yoges.moviesloverz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Show_Category extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show__category);
        getSupportActionBar().setTitle("Home");

        Bundle b=getIntent().getExtras();
        if(b!=null)
        {
            String name=b.getString("Name");
            Toast.makeText(this,"WELCOME "+name,Toast.LENGTH_SHORT).show();
        }

    }


    public void categoryToMovies(View view) {
        String category="";
        switch(view.getId())
        {
            case R.id.Category_Bollywood: category="Bollywood";
                break;
            case R.id.Category_Hollywood: category="Hollywood";
                break;
        }


        Intent i= new Intent(Show_Category.this,Show_Movies.class);
        i.putExtra("category",category);
        startActivity(i);
    }
}
