package com.example.yoges.moviesloverz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Forgot_Password extends AppCompatActivity {
    EditText ET_Email,ET_number;
    TextView TV_MSG;
    LoginDatabase db;
    LinearLayout layout;
    String email,password,number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot__password);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        db=new LoginDatabase(this);
        ET_Email=findViewById(R.id.forgot_email);
        ET_number=findViewById(R.id.forgot_number);
        TV_MSG=findViewById(R.id.msg);
        layout = findViewById(R.id.layout);
    }


    public void check(View view) {
        email=ET_Email.getText().toString();
        if(db.checkMail(email))
        {
         view.setVisibility(View.GONE);
         layout.setVisibility(View.VISIBLE);
            TV_MSG.setText("");
        }
        else
        {
            TV_MSG.setText("No Account Found");
        }
    }

    public void get(View view) {
        number=ET_number.getText().toString();
        password = db.getPassword(email,number);
        TV_MSG.setText(password);
    }
}
