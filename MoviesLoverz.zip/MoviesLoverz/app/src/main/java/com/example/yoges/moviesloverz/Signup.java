package com.example.yoges.moviesloverz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Signup extends AppCompatActivity {
    EditText ET_Name,ET_PH,ET_Email,ET_Password,ET_Password_confirm;
    String name,number,email,password,confirm_pass;
    LoginDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().setTitle("Sign Up  ");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        ET_Name=findViewById(R.id.signup_name);
        ET_PH=findViewById(R.id.signup_number);
        ET_Email=findViewById(R.id.signup_Email);
        ET_Password=findViewById(R.id.passwordin);
        ET_Password_confirm=findViewById(R.id.passwordinConf);
        db=new LoginDatabase(this);
    }


    public void Submit(View view) {
        name=ET_Name.getText().toString();
        number=ET_PH.getText().toString();
        email=ET_Email.getText().toString();
        password=ET_Password.getText().toString();
        confirm_pass=ET_Password_confirm.getText().toString();

        if(name.equals("")||number.equals("")||email.equals("")||password.equals("")||confirm_pass.equals(""))
        {
            Toast.makeText(this,"Every Field is Necessary",Toast.LENGTH_SHORT).show();
            return;
        }

        if(!password.equals(confirm_pass))
        {
            Toast.makeText(this,"Password didn't matched",Toast.LENGTH_SHORT).show();
        }
        else
        {
          long i= db.insert(name,number,email,password);
          if(i!=-1)
          {
              Toast.makeText(this, "Sign Up Successful", Toast.LENGTH_SHORT).show();
              Intent intent=new Intent(Signup.this,Show_Category.class);
              intent.putExtra("Name",name);
              startActivity(intent);
          }
          else
              Toast.makeText(this,"Email Already Registered",Toast.LENGTH_SHORT).show();
        }

    }


}
