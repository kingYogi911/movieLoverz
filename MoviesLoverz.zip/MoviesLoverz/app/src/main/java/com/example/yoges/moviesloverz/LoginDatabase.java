package com.example.yoges.moviesloverz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class LoginDatabase {
    public static final String DATABASE_NAME="MoviesLover.db";
    public static final int DATABASE_VERSION=1;
    public static String TABLE_NAME="LOGIN_DETAILS";
    private static String COL_0="Name";
    private static String COL_1="PHNumber";
    private static String COL_2="Email";
    private static String COL_3="Password";
    static final String CREATE_COMMAND="CREATE TABLE "+TABLE_NAME+" ("
            +COL_0+" TEXT,"
            +COL_1+" TEXT,"
            +COL_2+" TEXT,"
            +COL_3+" TEXT"
            +");";
    public static SQLiteDatabase db;
    public static  MyDatabaseHelper dbHelper;

    LoginDatabase(Context context)
    {
        dbHelper=new MyDatabaseHelper(context.getApplicationContext(),DATABASE_NAME,null,DATABASE_VERSION);
    }

    public long insert(String N,String PH,String E,String P)
    {
        db=dbHelper.getWritableDatabase();
        ContentValues newvalues =new ContentValues();
        newvalues.put(COL_0,N);
        newvalues.put(COL_1,PH);
        newvalues.put(COL_2,E);
        newvalues.put(COL_3,P);
        long i= db.insert(TABLE_NAME,null,newvalues);
        db.close();
        return i;
    }

    public Cursor getAll() {
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery("select * from "+TABLE_NAME, null);
        if(c!=null)
            c.moveToFirst();
        return c;
    }

    public String checkin(String email,String pass)
    {
        Cursor all=getAll();
        while(!all.isAfterLast())
        {  if(email.equals(all.getString(2)) && pass.equals(all.getString(3)))
            return all.getString(0);
            all.moveToNext();
        }
        return null;
    }

    public boolean checkMail(String email)
    {   Cursor c=getAll();
        while (!c.isAfterLast())
        {   if(email.equals(c.getString(2)))
            return true;
            c.moveToNext();
            }
        return false;
    }
    public String getPassword(String email,String number)
    {
     db=dbHelper.getReadableDatabase();
     Cursor c=db.rawQuery("select * from "+TABLE_NAME+" where "+COL_2+"==\'"+email+"\'",null);
     if(c!=null)
     {
         c.moveToFirst();
         if(number.equals(c.getString(1)))
         {
             return "Password = "+c.getString(3);
         }
     }
     return "Wrong Phone number";
    }
}
