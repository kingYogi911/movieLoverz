package com.example.yoges.moviesloverz;

import android.database.Cursor;

public class Movie {
    //private int ImageDrawable;
    private byte[] image;
    private String name;
    private String dlink;
    private String tlink;
    public static int bcount=0,hcount=0;
   Movie(Cursor c)
    {
        if(c.getString(0).equals("Bollywood"))
            bcount++;
        else
            hcount++;


        name=c.getString(1);
        image=c.getBlob(2);
        dlink=c.getString(3);
        tlink=c.getString(4);

    }

    public static int getCount(String category)
    {
        if(category.equals("Bollywood"))
            return bcount;
        else
            return hcount;
    }

    public String getTLink() {
        return tlink;
    }

    public void setTLink(String link) {
        this.tlink = link;
    }

    public String getDLink() {
        return dlink;
    }

    public void setDLink(String link) {
        this.dlink = link;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }



}
