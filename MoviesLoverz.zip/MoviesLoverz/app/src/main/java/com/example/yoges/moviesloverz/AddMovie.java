package com.example.yoges.moviesloverz;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;

import java.io.File;
import java.io.IOException;

public class AddMovie extends AppCompatActivity {
    String Category;
    String Name;
    byte[] image;
    String dLink,tLink;
    Spinner spinner;
    EditText ET_NAME;
    ImageButton imageButton;
    EditText ET_DLINK,ET_TLINK;
    MovieDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_movie);
        getSupportActionBar().setTitle("Add Movies");
        db=new MovieDatabase(getApplicationContext());

        spinner=findViewById(R.id.SPINNER);
        ET_NAME=findViewById(R.id.NAME);
        imageButton=findViewById(R.id.IMAGE);
        ET_DLINK=findViewById(R.id.DLINK);
        ET_TLINK=findViewById(R.id.TLINK);

        ArrayAdapter adapter= ArrayAdapter.createFromResource(this,R.array.Category,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position>0)
                {
                   if(id==1)
                       Category="Bollywood";
                   else
                       Category="Hollywood";


                   Toast.makeText(AddMovie.this,Category,Toast.LENGTH_SHORT).show();

                }
                            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void selectImage(View view) {
        Intent i=new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        startActivityForResult(Intent.createChooser(i,"Select Using"),0 );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==0&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)
        {
            Uri uri=data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(),uri);
                imageButton.setImageURI(uri);
                image=MovieDatabase.BitmapToByte(bitmap);
            }
            catch (IOException e)
            {
                e.printStackTrace();
                Toast.makeText(this,"Unable to convert to Bitmap",Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            Toast.makeText(this,"No image Choosed",Toast.LENGTH_SHORT).show();
        }
    }



    public void Addmovie(View view) {
        Name=ET_NAME.getText().toString();
        dLink=ET_DLINK.getText().toString();
        tLink=ET_TLINK.getText().toString();
        if(!(dLink.contains("https://")||dLink.contains("http://")))
        {
            Toast.makeText(AddMovie.this,"Unsupported Download Link \n Enter \"https://......\"",Toast.LENGTH_LONG).show();
            return;
        }
        if(!(tLink.contains("https://")||tLink.contains("http://")))
        {
            Toast.makeText(AddMovie.this,"Unsupported Trailer Link \n Enter \"https://......\"",Toast.LENGTH_LONG).show();
            return;
        }
            if(Category!=null && Name!=null && image!=null && !dLink.equals(""))
        {  long i= db.insertInMovies(Category,Name,image,dLink,tLink);
            if(i!=-1)
                Toast.makeText(this,"Movie added to the database",Toast.LENGTH_LONG).show();
            else
                Toast.makeText(this,"Error in adding to the database",Toast.LENGTH_LONG).show();
            startActivity(new Intent(this,AddMovie.class));
            finish();
        }
        else
        {
            Toast.makeText(this,"Every Filed is Neccesary to be filled",Toast.LENGTH_LONG).show();
        }

    }






}
