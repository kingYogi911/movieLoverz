package com.example.yoges.moviesloverz;

import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    LoginDatabase db;
    EditText ET_EMAIL,ET_PASS;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=new LoginDatabase(this);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflator= getMenuInflater();
        inflator.inflate(R.menu.menu_main,menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemid = item.getItemId();
        switch (itemid) {
            case R.id.admin : Intent i= new Intent(this,AdminLogin.class);
                startActivity(i);
            default: return super.onOptionsItemSelected(item);
        }
    }
    public void Login(View view) {
        ET_EMAIL=findViewById(R.id.login_email);
        ET_PASS=findViewById(R.id.login_password);
        tv=findViewById(R.id.forget_password);
        String email=ET_EMAIL.getText().toString();
        String pass=ET_PASS.getText().toString();
        if(email.equals("")||pass.equals(""))
        {
            Toast.makeText(this,"Enter Complete Details",Toast.LENGTH_SHORT).show();
            return;
        }
        String name=db.checkin(email,pass);
        if(name!=null) {
            Intent i = new Intent(this, Show_Category.class);
            i.putExtra("Name",name);
            startActivity(i);
            finish();
        }
        else
        {
            tv.setVisibility(View.VISIBLE);
        }

    }

    public void Signup(View view) {
        Intent i=new Intent(this,Signup.class);
        startActivity(i);
    }

    public void forgot(View view)
    {
        Intent i=new Intent(this,Forgot_Password.class);
        startActivity(i);
    }

}
