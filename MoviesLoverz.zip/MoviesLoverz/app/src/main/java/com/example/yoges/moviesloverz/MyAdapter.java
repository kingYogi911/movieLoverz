package com.example.yoges.moviesloverz;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

public class MyAdapter extends ArrayAdapter {
    private Context context;
    private ArrayList<Movie> mlist;
    MyAdapter(@NonNull Context context, ArrayList<Movie> mlist) {
        super(context,R.layout.customlayout,mlist);
        this.context=context;
        this.mlist=mlist;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View row=convertView;
        if(row==null) {
            LayoutInflater inflator = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflator.inflate(R.layout.customlayout, null, true);
        }

        TextView TV_NAME=row.findViewById(R.id.custom_Name);
        ImageView IMG=row.findViewById(R.id.custom_pic);
        Movie currentMovie=mlist.get(position);
        TV_NAME.setText(currentMovie.getName());
        IMG.setImageBitmap(MovieDatabase.ByteToBitmap(currentMovie.getImage()));
        //IMG.setImageResource(currentMovie.getImageDrawable());
        return row;
    }

    @Nullable
    @Override
    public Movie getItem(int position) {
        return mlist.get(position);
    }

}
