package com.example.yoges.moviesloverz;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DeleteMovies extends AppCompatActivity {
    EditText ET_NAME;
    ListView listView;
    MovieDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_movies);
        getSupportActionBar().setTitle("Delete Movies");

        ET_NAME=findViewById(R.id.NAME_TO_DELETE);
        listView=findViewById(R.id.list_to_delete);
        db=new MovieDatabase(this);
    }

    public void check(View view) {
        String name=ET_NAME.getText().toString();
        ArrayList<Movie> mlist=new ArrayList<>();
        Cursor cursor=db.getMoviesByNameLike(name);
        int count=0;
        while (!cursor.isAfterLast())
        {
            mlist.add(new Movie(cursor));
            count++;
            cursor.moveToNext();
        }
        if(count==0)
        {
            Toast.makeText(this,"No Movie with this Name",Toast.LENGTH_SHORT).show();
        }

        MyAdapter adapter=new MyAdapter(this,mlist);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Movie currentMovie= (Movie) parent.getItemAtPosition(position);
                AlertDialog dialog=creteDialog(currentMovie);
                dialog.show();
            }
        });
    }
     AlertDialog creteDialog(final Movie currentMovie)
     {
         AlertDialog.Builder builder=new AlertDialog.Builder(this);
         builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
             @Override
             public void onClick(DialogInterface dialog, int which) {
                 {
                     int i=db.deleteByName(currentMovie.getName());
                     if(i!=-1)
                         Toast.makeText(DeleteMovies.this,"Movie Deleted",Toast.LENGTH_SHORT).show();
                     Intent r=new Intent(DeleteMovies.this,DeleteMovies.class);
                     startActivity(r);
                     finish();
                 }
             }
         });
         builder.setNegativeButton("Back", new DialogInterface.OnClickListener() {
             @Override
             public void onClick(DialogInterface dialog, int which) {

             }
         });
         return builder.create();
     }
}
