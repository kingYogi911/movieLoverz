package com.example.yoges.moviesloverz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AdminLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        getSupportActionBar().setTitle("Admin Login");
    }

    public void adminLogin(View view) {
        String password=((EditText)findViewById(R.id.adminpassword)).getText().toString();
        if(password.equals("movieloverz123"))
        {
            startActivity(new Intent(AdminLogin.this,AdminOption.class));
            finish();
        }
        else
        {
            Toast.makeText(this,"Wrong PAssword ",Toast.LENGTH_SHORT).show();
        }
    }
}
