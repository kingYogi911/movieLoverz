package com.example.yoges.moviesloverz;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;

public class MovieDatabase {
        public static String TABLE_NAME="MoviesTable";
        private static String COL_0="Category";
        private static String COL_1="Name";
        private static String COL_2="Image";
        private static String COL_3="dLink";
        private static String COL_4="tLink";
    public static final String CREATE_COMMAND="CREATE TABLE "+TABLE_NAME+" ("
                +COL_0+" TEXT,"
                +COL_1+" TEXT,"
                +COL_2+" BLOB NOT NULL,"
                +COL_3+" TEXT,"
                +COL_4+" TEXT"
                + ");";
        private static SQLiteDatabase db;
        private static  MyDatabaseHelper dbHelper;

        MovieDatabase(Context context)
        {
            dbHelper=new MyDatabaseHelper(context.getApplicationContext(),LoginDatabase.DATABASE_NAME,null,LoginDatabase.DATABASE_VERSION);
        }

        public long insertInMovies(String Category,String Name,byte[] image,String dLink,String tLink)
        {
            db=dbHelper.getWritableDatabase();
            ContentValues newvalues =new ContentValues();
            newvalues.put(COL_0,Category);
            newvalues.put(COL_1,Name);
            newvalues.put(COL_2,image);
            newvalues.put(COL_3,dLink);
            newvalues.put(COL_4,tLink);
            long i= db.insert(TABLE_NAME,null,newvalues);
            db.close();
            return i;
        }
        public Cursor getMoviesByNameLike(String N)
        {
            db=dbHelper.getReadableDatabase();
            Cursor c= db.rawQuery("select * from "+TABLE_NAME+" where "+COL_1+" LIKE \'%"+N+"%\'",null);
            if(c!=null)
                c.moveToFirst();
            return c;
        }

        public Cursor getMoviebyCategory(String category)
        {
            db=dbHelper.getReadableDatabase();
            Cursor c= db.rawQuery("select * from " +TABLE_NAME+ " where "+COL_0+"==\'"+category+"\'",null);
            if(c!=null)
                c.moveToFirst();
            return c;
        }

        public Cursor getAllMovies() {
            db = dbHelper.getWritableDatabase();
            Cursor c = db.rawQuery("select * from "+TABLE_NAME, null);
            if(c!=null)
                c.moveToFirst();
            return c;
        }

        public int deleteByName(String Name)
        {
            db=dbHelper.getWritableDatabase();
            return db.delete(TABLE_NAME, COL_1 + "=?", new String[]{Name});
        }

    public static byte[] BitmapToByte(Bitmap bitmap)
    {
        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100,baos);
        return baos.toByteArray();
    }
    public static Bitmap ByteToBitmap(byte[] b)
    {
        return BitmapFactory.decodeByteArray(b,0,b.length);
    }




}





