package com.example.yoges.moviesloverz;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class Show_Movies extends AppCompatActivity{
    String[] name;
    int[] picid;
    String category;
    TypedArray ar;
    ListView list;
    ArrayList<Movie> mlist;
    Intent i;
    MovieDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show__movies);
        db=new MovieDatabase(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        category = getIntent().getExtras().getString("category");

        mlist = new ArrayList<>();
        Cursor cursor=db.getMoviebyCategory(category);
        int count=0;
        while (!cursor.isAfterLast()) {
            mlist.add(new Movie(cursor));
            count++;
            cursor.moveToNext();
        }

        if(count==0)
        {
            Toast.makeText(this,"No Movies to Show",Toast.LENGTH_SHORT).show();
        }

        MyAdapter adapter=new MyAdapter(this,mlist);

        list = findViewById(R.id.list_Movies);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Movie currentMovie= (Movie) parent.getItemAtPosition(position);
                AlertDialog dialog=createDialog(currentMovie);
                dialog.show();
            }
        });


    }

    public AlertDialog createDialog(final Movie currentMovie)
    {

        final AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setPositiveButton("Open Download Link", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent i=new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(currentMovie.getDLink()));
                startActivity(Intent.createChooser(i,"Open Link with"));
            }
        });

        builder.setNegativeButton("Watch Trailer", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent i=new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(currentMovie.getTLink()));
                startActivity(Intent.createChooser(i,"Open Link with"));
            }
        });

        builder.setNeutralButton("Back", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        return builder.create();
    }

}


